<h1 align="center">Expense Tracker for Android</h1>
<h3 align="center">Realizat de Farcas Tudor Ioan, gr. 30235</h3>
<img align="right" width="325" src="https://www.icegif.com/wp-content/uploads/money-icegif-28.gif">
<br>
<br>




<br>
<br>



<h3 align="left">Roadmap: </h3>

- [x] Add User / Register Design

- [x] Add design
<br>


<h3 align="left">Language and Framework used: </h3>
</div><img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">


Kotlin
<br>
Java
<br>
Firebase by Google



<h3 align="left">Actual Status: </h3>
</div><img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

- Partea de Log In si Register este facut, din punct de vedere al design-ului(partea in XML, ca partea de Java/Kotlin PUSCA!!!)
<br>

- Si butoanele de jos de pe activity main
