package com.example.project_is.activity


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.project_is.R
import com.example.project_is.databinding.ActivityMainBinding

class SignInActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.)
    }

}