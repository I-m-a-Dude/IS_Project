package com.example.project_is.activity

class RegisterActivity {
}