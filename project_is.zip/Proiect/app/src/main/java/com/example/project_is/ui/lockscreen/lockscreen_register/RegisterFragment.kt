package com.example.project_is.ui.lockscreen.lockscreen_register

class RegisterFragment {
}