package com.example.project_is.ui.lockscreen.lockscreen_main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel


class MainViewModel : ViewModel(){

        // You can add any logic or data manipulation related to the lock screen here


}